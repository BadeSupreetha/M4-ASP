﻿using StudentAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace StudentAPI.Controllers
{
    public class StudentsController : ApiController
    {
        Student[] students = new Student[] 
        {
            new Student
            {
                StudentID=101,
                FirstName="Ajai",
                LastName="Krishang",
                Age=22
            },
            new Student
            {
                StudentID=102,
                FirstName="Sangeetha",
                LastName="Aravindh",
                Age=32
            },
            new Student
            {
                StudentID=103,
                FirstName="Ganesh",
                LastName="Desai",
                Age=42
            },
            new Student
            {
                StudentID=104,
                FirstName="Vaishali",
                LastName="Kasture",
                Age = 30
            }
        };
        // use Default Route config
        //http://localhost:51029/api/Students
        public IEnumerable<Student> Get()
        {
            return students;
        }
      // http://localhost:51029/querystring/?Age=22&FirstName=Ajai&LastName=Krishang&StudentID=101
        [Route("querystring")]
        public IHttpActionResult GetStudent([FromUri]Student stud)
        {
            if (stud==null)
            {
                return BadRequest("Student is Required");
            }

            var student = students.FirstOrDefault((s) => s.StudentID == stud.StudentID);

            if(student==null)
            {
                return NotFound();
            }

            return Ok(student);
        }
    }
}
